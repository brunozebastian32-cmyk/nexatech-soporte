-- NEXATECH SOPORTE INTEGRAL
-- Ejecutá este script una vez en Supabase > SQL Editor.
-- El frontend usa SOLO la anon key. No pongas la service_role key en GitHub.

create table if not exists public.nexatech_state (
    id bigint primary key,
    state jsonb not null default '{}'::jsonb,
    updated_at timestamptz not null default now()
);

alter table public.nexatech_state enable row level security;

drop policy if exists "nexatech_public_read" on public.nexatech_state;
drop policy if exists "nexatech_public_write" on public.nexatech_state;

create policy "nexatech_public_read"
on public.nexatech_state
for select
to anon, authenticated
using (id = 1);

create policy "nexatech_public_write"
on public.nexatech_state
for insert
to anon, authenticated
with check (id = 1);

create policy "nexatech_public_update"
on public.nexatech_state
for update
to anon, authenticated
using (id = 1)
with check (id = 1);

-- No insertamos datos vacíos: la primera carga del sitio publicará
-- automáticamente los datos iniciales de Nexatech.
