# Nexatech Soporte Integral

Versión preparada para GitHub Pages + Supabase.

## 1. Crear Supabase

1. Creá un proyecto en Supabase.
2. Abrí **SQL Editor**.
3. Pegá todo el contenido de `supabase.sql`.
4. Ejecutalo.
5. En **Project Settings → API** copiá:
   - Project URL
   - Publishable/anon key

## 2. Configurar la página

Abrí `index.html` y buscá:

```js
const SUPABASE_URL = "https://TU-PROYECTO.supabase.co";
const SUPABASE_ANON_KEY = "TU-ANON-KEY";
```

Reemplazalos por los datos de tu proyecto.

**Nunca pongas la `service_role` key en GitHub.** La clave pública/anon está pensada para el frontend; las reglas RLS controlan el acceso.

## 3. Subir a GitHub Pages

Subí `index.html` y `supabase.sql` al repositorio.

En GitHub:
**Settings → Pages → Deploy from a branch → main → /root**

La URL quedará aproximadamente:

`https://TU-USUARIO.github.io/TU-REPOSITORIO/`

## 4. QR de las PCs

Cada PC recibe un token único.

El QR no guarda solamente el texto del token: guarda una URL como:

`https://TU-USUARIO.github.io/TU-REPOSITORIO/?pc_token=NEXATECH-PC-...`

Al escanearlo:

- no pide login;
- consulta Supabase;
- encuentra la PC por su token;
- muestra salón;
- estado;
- fecha de registro;
- código QR;
- historial de reparaciones.

Por eso el QR sigue funcionando desde otro celular o computadora mientras la página esté publicada y Supabase esté disponible.

## 5. Fallback local

Si todavía no configuraste Supabase, la página sigue funcionando con `localStorage`.

Cuando Supabase está configurado, el panel sincroniza:
- salones
- PCs
- switches
- reparaciones
- técnicos

Los profesores y sus credenciales continúan en el almacenamiento local del navegador en esta versión.

## Credenciales de prueba

Administrador:
- Email: `admin@nexatech.local`
- Contraseña: `NexaAdmin2026`

Profesor:
- Email: `profesor@utu.edu.uy`
- Contraseña: `1234`

## Nota de seguridad

Esta versión está pensada para el proyecto/demo de Nexatech. La política SQL permite escritura pública para que el panel estático pueda sincronizar sin un backend propio. Para producción real habría que pasar el login y las operaciones administrativas a Supabase Auth + RLS por usuario/rol.
